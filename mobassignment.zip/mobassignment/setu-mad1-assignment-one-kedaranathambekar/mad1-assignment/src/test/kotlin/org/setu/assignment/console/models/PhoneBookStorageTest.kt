package org.setu.assignment.console.models

import org.junit.jupiter.*
import org.junit.jupiter.api.*
import org.junit.jupiter.api.Assertions.*
import org.setu.assignment.console.Main.phone
import java.util.*


class PhoneBookStorageTest {
    private lateinit var phonetest: PhoneBookStorage

    @BeforeEach
    fun setUp(){

        phonetest = PhoneBookStorage()
        phonetest.create(PhonebookModel(0,"13212","12321","12321","1232"))
    }

    @Test
    fun addPhone() {

        val a = PhoneBookStorage()
        assert(a.create(PhonebookModel(15551,"kedhar","12345667","kd@gmail.com","Brother")))
        assert(a.create(PhonebookModel(15552,"Sam","87954563","jkl@gmail.com","Friend")))
        assert(a.create(PhonebookModel(15553,"kedhar","12345667","kd@gmail.com","Brother")))
    }
    @Test
    fun testDeleteItem() {

        val deleted = assert(phonetest.delete(PhonebookModel(15551, "kedhar", "12345667", "kd@gmail.com", "Brother")))
        val deleted1 = assert(phonetest.delete(PhonebookModel(15552, "Sam", "87954563", "jkl@gmail.com", "Friend")))
        val deleted2 = assert(phonetest.delete(PhonebookModel(15553, "kedhar", "12345667", "kd@gmail.com", "Brother")))
        assertTrue(deleted)
        assertTrue(deleted1)
        assertTrue(deleted2)
    }
    private fun assert(value: Unit) {
        phone.create(PhonebookModel(0,"hello","12656","12345@gmai.com","sistet"))

    }
    @Test
    fun testUpdateItem() {
        val updated = phonetest.update(PhonebookModel(0,"kedharnath","0124664","1452@gmail.com","friend"))
       assertTrue(updated)
//        val item = phonetest.findOne(0)
//        assertEquals("kedhar", item)
    }

    private fun assertTrue(updated: Unit) {

    }
}