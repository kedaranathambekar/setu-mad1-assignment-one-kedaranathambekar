package org.setu.assignment.console.models

data class PhonebookModel(
    var id: Long = 0,
    var Name:String ="",
    var contact:String ="",
    var email:String   ="",
    var relation:String =""
)