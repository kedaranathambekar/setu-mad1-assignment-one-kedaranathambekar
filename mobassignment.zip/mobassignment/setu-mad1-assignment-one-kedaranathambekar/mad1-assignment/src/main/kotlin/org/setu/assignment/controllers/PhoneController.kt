package org.setu.assignment.controllers


import mu.KotlinLogging
import org.setu.assignment.console.models.PhoneJSON
import org.setu.assignment.console.models.PhonebookModel
import org.setu.assignment.view.PhoneView

class PhoneController {

    //val phonemark= PhoneBookStorage()
    val phonemark= PhoneJSON()
    val phoneView = PhoneView()
    val logger = KotlinLogging.logger {}

    init {
        logger.info { "Launching Placemark Console App" }
        println("Placemark Kotlin App Version 1.0")
    }
    fun start() {
        var input: Int

        do {
            input = menu()
            when (input) {
                1 -> add()
                2 -> update()
                3 -> list()
                4 -> search()
                5 -> delete()
                6 -> listReltion()
                -1 -> println("Exiting App")
                else -> println("Invalid Option")
            }
            println()
        } while (input != -1)
        logger.info { "Shutting Down Placemark Console App" }
    }


    fun menu() :Int { return phoneView.menu() }

    fun add(){
        var aPhone = PhonebookModel()

        if (phoneView.addphone(aPhone))
            phonemark.create(aPhone)
        else
            logger.info("Contact is not added")
    }

    fun list() {
        phoneView.listphone(phonemark)
    }

    fun update() {

        phoneView.listphone(phonemark)
        var searchId = phoneView.getId()
        val aPhone = search(searchId)

        if(aPhone != null) {
            if(phoneView.upatephone(aPhone)) {
                phonemark.update(aPhone)
                phoneView.showPhone(aPhone)
                logger.info("Contact Updated : [ $aPhone ]")
            }
            else
                logger.info("Contact Not Updated")
        }
        else
            println("Contact Not Updated...")
    }

    fun search() {
        val aPhone = search(phoneView.getId())!!
        phoneView.showPhone(aPhone)
    }

    fun listReltion(){
        var a =phoneView.getRelation()
        val b= searchRelation(a)

        if(b !=null){
           // phoneView.listphoneRelation(b)
            phoneView.showPhoneContact(b)
        }


    }
    fun search(id: Long) : PhonebookModel? {
        var foundContact = phonemark.findOne(id)
        return foundContact
    }
    fun searchRelation(string: String) : List<PhonebookModel> {
        var foundContacts = phonemark.findRelation(string)
        return foundContacts
    }
    fun delete() {
        phoneView.listphone(phonemark)
        var searchId = phoneView.getId()
        val aPhone = search(searchId)

        if(aPhone != null) {
            phonemark.delete(aPhone)
            println("Contact Deleted...")
            phoneView.listphone(phonemark)
        }
        else
            println("Contact Not Deleted...")
    }
}
