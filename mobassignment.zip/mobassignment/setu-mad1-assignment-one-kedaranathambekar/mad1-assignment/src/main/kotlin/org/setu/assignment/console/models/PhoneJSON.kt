package org.setu.assignment.console.models

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import mu.KotlinLogging


import org.setu.assignment.helpers.*
import java.util.*

private val logger = KotlinLogging.logger {}

val JSON_FILE = "savecontact.json"
val gsonBuilder = GsonBuilder().setPrettyPrinting().create()
val listType = object : TypeToken<java.util.ArrayList<PhonebookModel>>() {}.type
fun generateRandomId(): Long {
    return Random().nextLong()
}

class PhoneJSON: PhoneBookInterface {

    var save = mutableListOf<PhonebookModel>()

    init {
        if (exists(JSON_FILE)) {
            deserialize()
        }
    }

    override fun findAll(): MutableList<PhonebookModel> {
        return save
    }

    override fun findOne(id: Long) : PhonebookModel? {
        var foundPlacemark: PhonebookModel? = save.find { p -> p.id == id }
        return foundPlacemark
    }

    override fun create(placemark: PhonebookModel) {
        placemark.id = generateRandomId()
        save.add(placemark)
        serialize()
    }

    override fun update(placemark: PhonebookModel) {
        var foundphone = findOne(placemark.id!!)
        if (foundphone != null) {
            foundphone.Name = placemark.Name
            foundphone.contact = placemark.contact
            foundphone.email = placemark.contact
            foundphone.relation = placemark.relation
        }
        serialize()
    }

    override fun logAll() {
        save.forEach { logger.info("${it}") }
    }

    private fun serialize() {
        val jsonString = gsonBuilder.toJson(save, listType)
        write(JSON_FILE, jsonString)
    }

    private fun deserialize() {
        val jsonString = read(JSON_FILE)
        save = Gson().fromJson(jsonString, listType)
    }

    override fun delete(placemark: PhonebookModel) {
        save.remove(placemark)
        serialize()
    }


    override fun findRelation(relation: String) : List<PhonebookModel> {
        var foundPlacemark: List<PhonebookModel> = save.filter { p -> p.relation == relation }

       // print("foundPlacemark " + foundPlacemark)
        return foundPlacemark
    }
}
