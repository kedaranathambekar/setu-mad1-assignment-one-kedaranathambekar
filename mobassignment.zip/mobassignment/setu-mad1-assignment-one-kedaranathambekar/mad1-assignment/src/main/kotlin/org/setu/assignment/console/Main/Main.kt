package org.setu.assignment.console.Main

import mu.KotlinLogging
import org.setu.assignment.console.models.PhoneBookStorage
import org.setu.assignment.console.models.PhonebookModel
import org.setu.assignment.controllers.PhoneController
import org.setu.assignment.view.PhoneView

val logger = KotlinLogging.logger {}
var phone = PhoneBookStorage()
val phonesview  = PhoneView()
val controller = PhoneController()
fun main(args: Array<String>) {
    PhoneController().start()
}
