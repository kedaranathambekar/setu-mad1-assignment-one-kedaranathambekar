package org.setu.assignment.console.models

import mu.KotlinLogging

private val logger = KotlinLogging.logger {}
private var lastId = 0L

private fun getId(): Long {
    return lastId++
}
class PhoneBookStorage : PhoneBookInterface {
    val phone = ArrayList<PhonebookModel>()


    override fun findAll(): List<PhonebookModel> {
        return phone
    }

    override fun findOne(id: Long) : PhonebookModel? {
        var foundPlacemark: PhonebookModel? = phone.find { p -> p.id == id }
        return foundPlacemark
    }

    override fun findRelation(relation: String) : List<PhonebookModel> {
        var foundPlacemark: List<PhonebookModel> = phone.filter { p -> p.relation == relation }

        return foundPlacemark
    }

    override fun create(phoneSystem: PhonebookModel) {
        phoneSystem.id = getId()
        phone.add(phoneSystem)
        logAll()
    }

    override fun update(phoneSystem: PhonebookModel) {
        var foundphone = findOne(phoneSystem.id!!)
        if (foundphone != null) {
            foundphone.Name = phoneSystem.Name
            foundphone.contact = phoneSystem.contact
            foundphone.email = phoneSystem.contact
            foundphone.relation = phoneSystem.relation
        }
    }

    override fun logAll() {
        phone.forEach { logger.info("${it}") }
    }
    override fun delete(phoneSystem: PhonebookModel) {
        phone.remove(phoneSystem)
    }
}