package org.setu.assignment.view

import org.setu.assignment.console.models.PhoneJSON
import org.setu.assignment.console.models.PhonebookModel

class PhoneView {
    fun menu(): Int {

        var option: Int
        var input: String? = null

        println("Main Menu")
        println(" 1. Add Phone Book")
        println(" 2. Update Phone Book")
        println(" 3. List Phone Book")
        println(" 4. search the Phone Book")
        println(" 5. Delete the Phone Book")
        println(" 6. Filter the Phone Book")
        println("-1. Exit")
        println()
        print("Enter an integer : ")
        input = readln()!!
        option = if (input.toIntOrNull() != null && !input.isEmpty())
            input.toInt()
        else
            -9
        return option
    }

    fun addphone(phone: PhonebookModel): Boolean {
        println("Add Phonebook")
        println()
        print("Enter a name : ")
        phone.Name = readln()!!
        println("Name Added: ${phone.Name}")
        println()
        print("Enter a contact: ")
        phone.contact = readln()!!
        println("Contact: ${phone.contact}")
        println()
        print("Enter Email-id: ")
        phone.email = readln()!!
        println("Email: ${phone.email}")
        println()
        print("Enter the relation: ")
        phone.relation = readln()!!
        println("Relation: ${phone.relation}")
        return phone.Name.isNotEmpty() && phone.email.isNotEmpty() && phone.contact.isNotEmpty() && phone.relation.isNotEmpty()

    }



    fun upatephone(phone: PhonebookModel) : Boolean {

        var newPhone: String?
        var newContact: String?
        var newEmail: String?
        if (phone != null) {
            print("Enter a new name for ${phone.Name}   : ")
            newPhone = readln()!!
            print("Enter a new contact for ${phone.contact} : ")
            newContact = readln()!!
            print("Enter a new Email-id ${phone.email}: ")
            newEmail = readln()!!
            println("You updated ${phone.Name} for name , ${phone.contact} for contact and ${phone.email} for email")
            if (!newPhone.isNullOrEmpty() && !newContact.isNullOrEmpty() && !newEmail.isNullOrEmpty()) {
                phone.Name=newPhone
                phone.contact=newContact
                phone.email=newEmail
                return true
            }
        }
        return false
    }


    fun listphone(phones: PhoneJSON){
        println("List All contacts for")
        println()
        phones.logAll()
        println()


    }

    fun listphoneRelation(phones: List<PhonebookModel>) {
        println()
        phones.forEach {
            print("\n" + it)
        }

    }

    fun getId() : Long {
        var strId : String? // String to hold user input
        var searchId : Long // Long to hold converted id
        print("Enter id to Search/Update/Delete : ")
        strId = readln()!!
        searchId = if (strId.toLongOrNull() != null && !strId.isEmpty())
            strId.toLong()
        else
            -9
        return searchId
    }

    fun getRelation() : String {
        var strId : String? // String to hold user input
        var searchIds : String? // Long to hold converted id
        print("Enter relation to find : ")
        strId = readln()!!
        searchIds = strId.toString()
       // print(" SearchID = " + searchIds)
        return searchIds
    }


    fun showPhone(contact : PhonebookModel) {
        if(contact != null)
            println("Contact Details [ $contact]")
        else
            println("Contact Not Found...")
    }

    fun showPhoneContact(contact : List<PhonebookModel>) {
        if(contact != null)
            println("Contact Details [ $contact]"+"\n")
           // println(" \n" +contact)
        else
            println("Contact Not Found...")
    }

}