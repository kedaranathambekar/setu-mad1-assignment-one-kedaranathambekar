package org.setu.assignment.console.models

interface PhoneBookInterface {
    fun findAll(): List<PhonebookModel>
    fun findOne(id: Long): PhonebookModel?
    fun findRelation(relation: String) : List<PhonebookModel>?
    fun create(phoneSystem: PhonebookModel)
    fun update(phoneSystem: PhonebookModel)
    fun logAll()
    fun delete(phoneSystem: PhonebookModel)
}